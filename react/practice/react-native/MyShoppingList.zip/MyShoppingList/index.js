import { AppRegistry } from 'react-native';
import App from './src/App/App.js';

AppRegistry.registerComponent('MyShoppingList', () => App);
